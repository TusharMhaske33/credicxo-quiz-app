import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  CanActivateChild,
  Router
} from '@angular/router';
import { SharedService } from '../shared/shared.service';
import { AppConstants } from './app.constants';


@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private sharedService: SharedService,
    private route:Router
  ) { }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    return this.checkIsAuthorized(AppConstants.isAuthenticated);
  }

 
  checkIsAuthorized(key: string): boolean {
    let flag = this.sharedService.checkCookie(key)
    if(flag){
      return true;
    }else{
      this.route.navigate(['/auth'])
      return false
    }
    
  }
}
