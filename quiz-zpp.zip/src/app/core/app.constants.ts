import { UserModel } from "./common.response.model";

export class AppConstants {
    public static setUser = "users";
    public static getUsers = "users";
    public static currentUser = "currentUser";
    public static isAuthenticated = "isAuthenticated";
    public static results = 'results'
    public static quizTime: number = 20
}

export interface OptionsModel { id: number; option: string; isCorrect: boolean; isSelected?: boolean }

export interface QuestionsModel {
    questionId: number;
    question: string;
    isSelected?: boolean;
    options: OptionsModel[];
}


export type PageStates = 'start' | 'started' | 'completed' | 'resumed'

export interface QuizPageModel {
    pageState: PageStates;
    quizTime: string;
    isNewTest: string;
    questions: QuestionsModel[];
    currentQuestionIndex: number;
}


export interface ResultsModel {
    currentUser: UserModel;
    result: QuestionsModel[];
}