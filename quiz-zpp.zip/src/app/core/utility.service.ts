import { ChangeDetectorRef, Injectable } from '@angular/core';
import { ResponseState } from './common.response.model';

// Declared as const as this should not be reassigned from anywhere in app


@Injectable()
export class Utility {

    static apiErrorMessage = {
        
        601: "email", // registerration form
        602: "phone", // registeration form
        603: "otp" // otp form 
    }
    
    public static extractErrorMessage(err: ResponseState): any {
        let object = {
            field: null,
            error: null
        }
        try {
            object.field = Utility.apiErrorMessage[err.responseStatus]
            object.error = err.responseMessage
        } catch (error) {
            object.field = null
            object.error = null
        }
        // Utility._cdr.();
        return object;
    }

    public method() {

    }
}
