export class ResponseState {
    responseMessage: string;
    responseStatus: number;
    response?: string | UserModel[] | any;
}


export class UserModel {
    name: string;
    password: string;
    email: string;
}