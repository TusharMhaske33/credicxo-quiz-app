import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { AppConstants } from '../core/app.constants';
import { ResponseState } from '../core/common.response.model';
import { HeaderComponent } from '../admin/components/header/header.component';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  public setCurrentUser: BehaviorSubject<any> = new BehaviorSubject(null);
  public getCurrentUser = this.setCurrentUser.asObservable();

  constructor(private cookieService: CookieService,
    private router: Router) { }


  /**
   * 
   * Method is responsible for getting data fo perticular cookie
   */
  public get(key): Observable<ResponseState> {
    let resp = this.getCookie(key);
    return of(this.createResponse(200, "list got success", resp))
  }



  /**
   * 
   * @param key is the variable used to store the data into specific cookie with respective name 
   * @param value is the data of that respective cookie
   */
  setCookie(key, value) {
    // this.cookieService.set(key, JSON.stringify(value));
    localStorage.setItem(key, JSON.stringify(value));
  }


  /**
   * 
   * @param key is used to identify which cookie need to fetch 
   * @returns 
   */
  getCookie(key) {
    // return JSON.parse(this.cookieService.get(key) || '[]')
    return JSON.parse(localStorage.getItem(key) || '[]')
  }

  /**
   * check cookie is available or not
   */
  checkCookie(key: string) {
    // return this.cookieService.check(key)
    return Boolean(localStorage.getItem(key))

  }

  /**
   * 
   * @param key delete the cookie of specified key
   * @returns return true/false respective to is deleted or not
   */
  deleteCokkie(key: string) {
    return localStorage.removeItem(key)
    // return this.cookieService.delete(key)
  }


  /**
   * 
   * @param status of the response message
   * @param message actuall response message
   * @param value value to send back
   * @returns 
   */
  createResponse(status, message, value): ResponseState {
    return {
      responseMessage: message,
      responseStatus: status,
      response: value
    }
  }

  /**
   * set the user is logged in for header
   */
  setUserAuth() {
    this.setCurrentUser.next(this.getCookie(AppConstants.currentUser));
  }


  logoutUser() {
    this.setCurrentUser.next(null);
    // delete auathprized key of user
    this.deleteCokkie(AppConstants.isAuthenticated);
    this.deleteCokkie(AppConstants.currentUser);

    // navigate to the auth module & register component
    this.router.navigate(['/auth'])
  }
}
