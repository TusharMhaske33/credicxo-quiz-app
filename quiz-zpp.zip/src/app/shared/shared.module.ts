import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { RouterModule } from '@angular/router';
import { AuthGuard } from '../core/auth-guard.service';
import { NotFoundComponent } from './not-found/not-found.component';



@NgModule({
  declarations: [NotFoundComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  exports: [NotFoundComponent, FormsModule, ReactiveFormsModule, CommonModule, RouterModule],
  providers: [CookieService, AuthGuard]
})
export class SharedModule { }
