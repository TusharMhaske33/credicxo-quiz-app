import { QuestionsModel } from "src/app/core/app.constants";

export const Questions: QuestionsModel[] = [
    {
        questionId: 1,
        question: 'What is angular data',
        options: [
            { id: 1, option: 'gfjsdhgjfs', isCorrect: true },
            { id: 2, option: 'rtyfee', isCorrect: false },
            { id: 3, option: 'fgsjdfh sgfhvs gvdha', isCorrect: false },
            { id: 4, option: 'dasytd sdffsaydghafas', isCorrect: false }
        ]
    },
    {
        questionId: 2,
        question: 'why angular is here',
        options: [
            { id: 1, option: 'dsgjd asdfufs dfstydca', isCorrect: false },
            { id: 2, option: 'fssd msfgjv ', isCorrect: false },
            { id: 3, option: 'fsdjh sadsgdjdv asgdd asvdgh dsavdfv', isCorrect: true },
            { id: 4, option: 'fsdfs sgsjda hg dasdas', isCorrect: false }
        ]
    },
    {
        questionId: 3,
        question: 'when is created by google',
        options: [
            { id: 1, option: 'fsgdf nfgfv nfgjd dafda svjdajvd', isCorrect: false },
            { id: 2, option: 'fsdfds', isCorrect: true },
            { id: 3, option: 'fsf fsd dsf', isCorrect: false },
            { id: 4, option: 'fds sdfd ssdf dssdsdf ds', isCorrect: false }
        ]
    },
    {
        questionId: 4,
        question: 'Is the angular is usefull?',
        options: [
            { id: 1, option: 'gtsduyfdsg fgsahcd gfascd a', isCorrect: false },
            { id: 2, option: 'fsdf sdfsd fdds fdsf', isCorrect: false },
            { id: 3, option: 'fsdfsdfsdfdsfs', isCorrect: false },
            { id: 4, option: 'fdsdf fdsfkdsbfsdfgdsjv sfssdcsgd sddfsa dnsbavda', isCorrect: true }
        ]
    },
    {
        questionId: 5,
        question: 'Where angular is developed and who ?',
        options: [
            { id: 1, option: 'fdsfs vjf dsfv dfnvsdffhvs schfdsdfdfvasdgajda', isCorrect: false },
            { id: 2, option: 'fdsfdsfvgj dfgjdsvfdvshgcsah dasv', isCorrect: false },
            { id: 3, option: 'fdsf sdfdgdsf dsgfsvgsfvhs dsdaccda', isCorrect: true },
            { id: 4, option: 'fdsfv fnjhgdfas dascd asdcsah', isCorrect: false }
        ]
    }
]