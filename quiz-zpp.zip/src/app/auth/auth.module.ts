import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthRoutingModule } from './auth-routing.module';
import { RegisterComponent } from './components/register/register.component';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { CommonAuthService } from './services/auth-common.service';
import { LoginComponent } from './components/login/login.component';

@NgModule({
  declarations: [RegisterComponent,LoginComponent],
  imports: [
    CommonModule,
    RouterModule,
    AuthRoutingModule,
    SharedModule
  ],
  providers: [CommonAuthService]
})
export class AuthModule { }
