import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { AppConstants } from 'src/app/core/app.constants';
import { ResponseState, UserModel } from 'src/app/core/common.response.model';
import { SharedService } from 'src/app/shared/shared.service';

@Injectable({
  providedIn: 'root'
})
export class CommonAuthService {
  currentOtp: number = 0;

  constructor(public sharedService: SharedService) { }

  /**
     * this method will responsible to store the data into storage
    */
  public register(key, value: UserModel): Observable<ResponseState> {
    if (this.sharedService.checkCookie(key)) {
      let allUsersData: UserModel[] = this.sharedService.getCookie(key);

      // check is email already existed
      if (this.isDuplicate(allUsersData, value.email, 'email')) {
        return throwError(this.sharedService.createResponse(601, "Email is already exist", null))
      }

      //push new user registration object to array
      allUsersData.push(value);

      // update cookie with newly added user       
      this.sharedService.setCookie(key, allUsersData)
    } else {
      // set cookie with for user
      this.sharedService.setCookie(key, [value])
    }
    let resp: ResponseState = this.sharedService.createResponse(200, 'Saved successfully', value)
    return of(resp);
  }



  /**
     * this method will responsible to login the user
    */
  public login(key, value: UserModel): Observable<ResponseState> {
    let allUsersData: UserModel[] = this.sharedService.getCookie(key);

    const isUserAvailable = allUsersData.findIndex(e => e.email == value.email && e.password == value.password);

    // check is email already existed
    if (isUserAvailable == -1) {
      return throwError(this.sharedService.createResponse(404, 'Invalid email or password', null))
    }
    this.sharedService.setCookie(AppConstants.isAuthenticated, true);
    this.sharedService.setCookie(AppConstants.currentUser, allUsersData[isUserAvailable]);
    // update cookie with newly added user       
    this.sharedService.setCurrentUser.next(allUsersData[isUserAvailable]);

    let resp: ResponseState = this.sharedService.createResponse(200, 'User login success', allUsersData[isUserAvailable]);
    return of(resp);
  }




  /**
   * 
   * @param array is for array of object to check from duplicate field
   * @param field is the value which needs to be checked
   * @param fieldText is the key which needs to be mapped
   * @returns true / false
   */
  isDuplicate(array, field, fieldText) {
    var isPresent = array.some(function (el) { return el[fieldText] == field });
    return isPresent
  }


  /**
   * 
   * @param value is the object with otp entered by user
   * @returns is otp verified success or not
   */
  verifyOtp(value): Observable<ResponseState> {
    if (value.otp == this.currentOtp) {
      this.sharedService.setUserAuth()
      return of(this.sharedService.createResponse(200, "OTP verified successfully", null));
    } else {
      return throwError(this.sharedService.createResponse(603, "Invalid OTP entered", null))
    }
  }

  sendOtp() {
    this.currentOtp = Math.floor(Math.random() * 9999) + 1001;
    return this.currentOtp;
  }
}
