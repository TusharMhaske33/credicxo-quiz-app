import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { AppConstants } from 'src/app/core/app.constants';
import { ResponseState } from 'src/app/core/common.response.model';
import { Utility } from 'src/app/core/utility.service';
import { ValidationConstants } from 'src/app/core/validation.constants';
import { CommonAuthService } from '../../services/auth-common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  title = "Quiz : Login"

  public loginFrm: FormGroup;

  pageModel = {
    pageMessage: null,
    isLoginSubmited: false,
    isOtpSubmited: false,
    isOtpTimeOut: false,
    isLoginSuccess: false,
    otpElapsedTime: null,
    validOtp: 0
  }

  constructor(private fb: FormBuilder,
    private loginService: CommonAuthService,
    private _cdr: ChangeDetectorRef,
    private route: Router,
    private pageTitle: Title
  ) {
    this.pageTitle.setTitle(this.title);
  }

  ngOnInit() {
    /**
   * login form init
   */
    this.loginFrm = this.fb.group({
      email: ['', [Validators.required, Validators.pattern(ValidationConstants.EMAIL_REGEX)]],
      password: ['', [Validators.required]],
    })


  }


  /**
 * getter for login form controls
 */
  get getLoginFrm() {
    return this.loginFrm.controls
  }

  /**
   * 
   * The functions used to login the user
   */
  loginUser() {
    this.pageModel.pageMessage = null;
    this.pageModel.isLoginSubmited = true
    if (this.loginFrm.invalid)
      return false;
    this.loginService.login(AppConstants.setUser, this.loginFrm.value).subscribe((respData: ResponseState) => {
      alert("login success");
      this.pageModel.isLoginSuccess = true;
      this.route.navigateByUrl('/admin');
    }, (error) => {
      this.pageModel.pageMessage = error.responseMessage;
    })

  }


  // The function used to reset the form with all fields and errors 
  resetForm() {
    this.loginFrm.reset();
    this.pageModel.isLoginSubmited = false
  }


}
