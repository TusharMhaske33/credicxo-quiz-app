import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { AppConstants } from 'src/app/core/app.constants';
import { ResponseState } from 'src/app/core/common.response.model';
import { Utility } from 'src/app/core/utility.service';
import { ValidationConstants } from 'src/app/core/validation.constants';
import { CommonAuthService } from '../../services/auth-common.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  title = "Quiz : Register user"

  public registerFrm: FormGroup;
  public otpForm: FormGroup;

  pageModel = {
    pageMessage: null,
    isRegisterSubmited: false,
    isOtpSubmited: false,
    isOtpTimeOut: false,
    isRegistrationSuccess: false,
    otpElapsedTime: null,
    validOtp: 0
  }

  constructor(private fb: FormBuilder,
    private registerService: CommonAuthService,
    private _cdr: ChangeDetectorRef,
    private route: Router,
    private pageTitle: Title
  ) {
    this.pageTitle.setTitle(this.title);
  }

  ngOnInit() {
    /**
   * registration form init
   */
    this.registerFrm = this.fb.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(ValidationConstants.EMAIL_REGEX)]],
      password: ['', [Validators.required]]
    })

    /**
     * OTP form init
     */
    this.otpForm = this.fb.group({
      otp: ['', [Validators.required, Validators.pattern(ValidationConstants.NUMBER_ONLY)]],
    })

  }


  /**
 * getter for registration form controls
 */
  get regFrm() {
    return this.registerFrm.controls
  }



  /**
   * 
   * The functions used to register the user
   */
  registerUser() {
    this.pageModel.pageMessage = null;
    this.pageModel.isRegisterSubmited = true
    if (this.registerFrm.invalid)
      return false;
    this.registerService.register(AppConstants.setUser, this.registerFrm.value).subscribe((respData: ResponseState) => {
      alert("Registration success, Please login");
      this.pageModel.isRegistrationSuccess = true
      this.route.navigateByUrl('/auth/login');
    }, (error) => {
      this.pageModel.pageMessage = error.responseMessage;
    })

  }


  // The function used to reset the form with all fields and errors 
  resetForm() {
    this.registerFrm.reset();
    this.pageModel.isRegisterSubmited = false
  }




}


// resendOtpTimer(remaining) {
//   let timerOn = true;
//   var m: string | number = Math.floor(remaining / 60);
//   var s: string | number = remaining % 60;

//   m = m < 10 ? '0' + m : m;
//   s = s < 10 ? '0' + s : s;

//   // document.getElementById('timer').innerHTML = m + ':' + s;

//   this.pageModel.otpElapsedTime = m + ':' + s
//   remaining -= 1;

//   if (remaining >= 0 && timerOn) {
//     setTimeout(() => {
//       this.resendOtpTimer(remaining);
//     }, 1000);
//     return;
//   }

//   if (!timerOn) {
//     // Do validate stuff here
//     return;
//   }

//   // timeout stuff here
//   this.pageModel.otpElapsedTime = null
// }