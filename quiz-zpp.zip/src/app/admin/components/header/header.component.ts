import { Component, OnInit } from '@angular/core';
import { AppConstants } from 'src/app/core/app.constants';
import { UserModel } from 'src/app/core/common.response.model';
import { SharedService } from '../../../shared/shared.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  isLoggedIn: boolean = false;
  currentUser: UserModel = null;
  constructor(
    private sharedService: SharedService
  ) { }

  ngOnInit(): void {
    /**
     * if is user already logged in then it should show logout on init
     */
    if (this.sharedService.checkCookie(AppConstants.isAuthenticated)) {
      this.isLoggedIn = true
      this.sharedService.getCurrentUser.subscribe((resp: UserModel) => {
        this.currentUser = resp;
        console.log(this.currentUser)
      })
    }

    /**
     * static property to access members of class from other classes
     */
  }

  logoutUser() {
    this.sharedService.logoutUser()
  }

}
