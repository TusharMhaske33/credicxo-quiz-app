import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConstants, PageStates, QuizPageModel } from 'src/app/core/app.constants';
import { Questions } from 'src/app/shared/db/questions';
import { SharedService } from 'src/app/shared/shared.service';


@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.scss']
})
export class QuizComponent implements OnInit {

  public pageModel: QuizPageModel = {
    pageState: 'start',
    quizTime: null,
    isNewTest: null, // for to check is test resumed or first time
    questions: [],
    currentQuestionIndex: -1
  }

  constructor(
    private sharedData: SharedService,
    private route: Router
  ) { }

  ngOnInit(): void {
    this.pageModel.questions = this.shuffle(Questions);
    this.prepareQuestions();
    this.pageModel.currentQuestionIndex = 0;
  }

  // this function will add isSelected : false for both question & respective options
  prepareQuestions() {
    this.pageModel.questions = this.pageModel.questions.map((e, index) => {
      this.clearOptions(index);
      e.isSelected = false;
      return e;
    })
  }

  // pass question index this method will clear selected option
  clearOptions(qIndex: number): void {
    this.pageModel.questions[qIndex].options = this.pageModel.questions[qIndex].options.map((e) => { e.isSelected = false; return e; })
  }

  previousQue() {
    this.pageModel.currentQuestionIndex--;
  }

  nextQue() {
    if (this.pageModel.currentQuestionIndex < this.pageModel.questions.length-1)
      this.pageModel.currentQuestionIndex++;
  }

  // on click option navigate to next question in 1 sec
  giveAnswer(optionIndex: number): void {
    this.pageModel.questions[this.pageModel.currentQuestionIndex].isSelected = true;
    this.clearOptions(this.pageModel.currentQuestionIndex);
    this.pageModel.questions[this.pageModel.currentQuestionIndex].options[optionIndex].isSelected = true;

    setTimeout(() => {
      this.nextQue();
    }, 300)
  }


  // submit final quiz
  submitQuiz() {
    console.log("Submited quiz : ", this.pageModel.questions, this.sharedData.checkCookie(AppConstants.results));
    const obj = {
      currentUser: this.sharedData.getCookie(AppConstants.currentUser),
      result: this.pageModel.questions
    };
    const d = this.sharedData.checkCookie(AppConstants.results)
    if (d == false) {
      this.sharedData.setCookie(AppConstants.results, [obj]);
    } else {
      const results: any[] = this.sharedData.getCookie(AppConstants.results);
      results.push(obj);
      this.sharedData.setCookie(AppConstants.results, results);
    }

    this.route.navigateByUrl('/admin/result')

  }

  // every time this function will shuffle questions array 
  shuffle(array) {
    let currentIndex = array.length, randomIndex;
    // While there remain elements to shuffle.
    while (currentIndex != 0) {
      // Pick a remaining element.
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;
      // And swap it with the current element.
      [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
    }
    return array;
  }

  // change the page states
  changePageState(state: PageStates): void {
    this.pageModel.pageState = state;
  }
}
