import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppConstants, ResultsModel } from 'src/app/core/app.constants';
import { ResponseState, UserModel } from 'src/app/core/common.response.model';
import { SharedService } from 'src/app/shared/shared.service';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss']
})
export class ResultComponent implements OnInit {

  title = "Users list";

  /**
   * list of users will be store into this array
   */
  public usersList: {
    name: string;
    obtained: number;
    total: number
  }[] = [];

  //pagination configuration
  public paginationConfig = {
    itemsPerPage: 6,
    currentPage: 0,
    totalItems: 0,
    id: "usersPaginate"
  };

  // pagination labels configuration
  public labels: any = {
    previousLabel: '<',
    nextLabel: '>',
    screenReaderPaginationLabel: 'Pagination',
    screenReaderPageLabel: 'page',
    screenReaderCurrentLabel: `You're on page`
  };



  constructor(private sharedData: SharedService) { }


  ngOnInit(): void {
    this.createResult();
  }

  createResult(): void {
    const results: ResultsModel[] = this.sharedData.getCookie(AppConstants.results);
    let usersList = [];

    results.map((user) => {
      let obj = {
        name: null,
        obtained: 0,
        total: results.length
      }
      obj.name = user.currentUser.name;

      user.result.forEach((question) => {
        if (question.isSelected) { // if question is selected then only check is correct or not
          question.options.forEach((option) => {
            if (option.isCorrect && option.isSelected) {
              obj.obtained++;
            }
          })
        }
      })
      usersList.push(obj);
    })

    this.sortByMarksObtained(usersList);

  }


  sortByMarksObtained(usersList: any[]) {
    this.usersList = usersList.sort((a, b) => b.obtained - a.obtained);
  }


  //the data member is responsible for toggling the sort order
  sortReverse = true


  // The function is responsible to handel the sort table data by given field 
  sortOrders(sortByProperty) {
    if (this.sortReverse) {
      this.usersList.sort((a, b) => (a[sortByProperty] > b[sortByProperty] ? 1 : ((b[sortByProperty] > a[sortByProperty]) ? -1 : 0)));
      this.sortReverse = false
    } else {
      this.usersList.sort((a, b) => (a[sortByProperty] > b[sortByProperty] ? -1 : ((b[sortByProperty] > a[sortByProperty]) ? 1 : 0)));
      this.sortReverse = true
    }
  }

}
