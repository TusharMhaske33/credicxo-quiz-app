import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { HeaderComponent } from './components/header/header.component';
import { AdminComponent } from './admin.component';
import { ResultComponent } from './components/result/result.component';
import { QuizComponent } from './components/quiz/quiz.component';


@NgModule({
  imports: [
    CommonModule,
    AdminRoutingModule,
    SharedModule,
    RouterModule,
    NgxPaginationModule
  ],
  declarations: [
    HeaderComponent, 
    QuizComponent, 
    ResultComponent, 
    AdminComponent],
  providers: []
})
export class AdminModule { }
